# export MYPYPATH=./stubs/
chmod +x ../src/courier.py
